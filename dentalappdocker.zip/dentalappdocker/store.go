package main

import (
	_ "github.com/go-sql-driver/mysql"
	"github.com/jinzhu/gorm"
	_ "github.com/jinzhu/gorm/dialects/mysql"
	"log"
)

	var db *gorm.DB


func createModel(){

	var err error
	db, err = gorm.Open("mysql", "root:vignesh@tcp(127.0.0.1:3306)/cisdb?charset=utf8&parseTime=True")

	if err != nil {
		log.Panic(err)
	}
	log.Println("Connection Established")
	//db.DropTableIfExists(&UserModel{})
	db.AutoMigrate(&Department{})

}

func  CreateDepartment(department *Department){
	tx := db.Begin()
	//To insert or create the record.
	//NOTE: we can insert multiple records too
	db.Debug().Create(department)

	tx.Commit()
	//return err
}
func GetDepartments() ([]*Department, error) {
	// Query the database for all birds, and return the result to the
	// `rows` object
	var resultArr []*Department
	db.Find(&resultArr)

	return resultArr, nil
}

